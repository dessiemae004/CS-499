document.getElementById('contactForm').addEventListener('submit', function(event) {
	event.preventDefault();

	const fname = document.getElementById('fname').value;
	const lname = document.getElementById('lname').value;
	const pnumber = document.getElementById('pnumber').value;
	const Option = document.getElementById('Option').value;


	const data = { fname: fname, lname:lname, pnumber:pnumber, Option: Option};

	fetch('server.php', {
		method: 'POST',
		headers: {
			'Content-Type': 'application/json'
		},
		body: JSON.stringify(data)
	})
	.then(response => response.text())
    .then(data => {
        console.log('Success:', data);
    })
    .catch((error) => {
        console.error('Error:', error);
    });
});





function myFunction(){
	alert("Here is your discount code of 20% on all formal items! FORM20");
	}