<?php
header("Access-Control-Allow-Origin: http://localhost");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");

$servername = "localhost";
$username = "root";
$password = "Jacob!22";
$dbname = "custcontact";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$data = json_decode(file_get_contents('php://input'), true);

// Debugging: Log the incoming data to see if the fields are received correctly
file_put_contents('php://stderr', print_r($data, true));  // Logs data to PHP error log

if (!$data || !isset($data['fname']) || !isset($data['lname']) || !isset($data['pnumber']) || !isset($data['option'])) {
    echo json_encode(['success' => false, 'message' => 'Missing required fields']);
    exit;
}

// Sanitize and prepare values
$fName = $data['fname'];
$lName = $data['lname'];
$pNumber = $data['pnumber'];
$userOption = $data['option'];

// Use a prepared statement to insert the data securely
$stmt = $conn->prepare("INSERT INTO custcontact.info (fName, lName, pNumber, userOption) VALUES (?, ?, ?, ?)");
$stmt->bind_param("ssss", $fName, $lName, $pNumber, $userOption);

if ($stmt->execute()) {
    echo json_encode(['success' => true, 'message' => 'New record created successfully']);
} else {
    echo json_encode(['success' => false, 'message' => 'Error inserting data']);
}

$stmt->close();
$conn->close();
?>