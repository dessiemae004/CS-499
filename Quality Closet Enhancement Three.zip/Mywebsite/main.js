document.getElementById('contactForm').addEventListener('submit', function(event) {
    event.preventDefault();  // Prevents the default form submission

    const fname = document.getElementById('fname').value;
    const lname = document.getElementById('lname').value;
    const pnumber = document.getElementById('pnumber').value;
    const option = document.getElementById('Option').value;

    console.log('Form Data:', { fname, lname, pnumber, option }); // Log the form data

    // Validate form fields
    if (!fname || !lname || !pnumber || !option) {
        alert('Please fill in all fields.');
        return;
    }

    const data = { fname: fname, lname: lname, pnumber: pnumber, option: option };

    fetch('http://localhost/Mywebsite/server.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)  // Send data as JSON
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.json();
    })
    .then(data => {
        console.log('Success:', data);  // Log the response from PHP
    })
    .catch((error) => {
        console.error('Error:', error);  // Log any errors
    });
});