
insert into custContact.info (fName, lName, pNumber, userOption) values ("Jake", "Kinworth", "4443335555", "No");

SELECT * from custContact.info;