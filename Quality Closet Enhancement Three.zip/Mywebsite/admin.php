<?php
// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Database connection settings
$servername = "localhost";
$username = "root";
$password = "Jacob!22";  // Make sure this matches your XAMPP MySQL password
$dbname = "custcontact";

// Create a new connection to the database
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch all records from the database
$sql = "SELECT * FROM info";
$result = $conn->query($sql);

// Check if any records are found
if ($result->num_rows > 0) {
    echo "<h1>Admin Dashboard - All Records</h1>";
    echo "<table border='1' cellpadding='10' cellspacing='0'>";
    echo "<tr><th>First Name</th><th>Last Name</th><th>Phone Number</th><th>Option (Can be texted?)</th></tr>";

    // Output each record in a table row
    while($row = $result->fetch_assoc()) {
        // Adjust the code below to use the actual column names
        echo "<tr>";
        echo "<td>" . $row["fName"] . "</td>";  // Assuming the column name is fName
        echo "<td>" . $row["lName"] . "</td>";  // Assuming the column name is lName
        echo "<td>" . $row["pNumber"] . "</td>";  // Assuming the column name is pNumber
        echo "<td>" . $row["userOption"] . "</td>";  // Assuming the column name is userOption
        echo "</tr>";
    }
    
    echo "</table>";
} else {
    echo "No records found.";
}

// Close the database connection
$conn->close();
?>