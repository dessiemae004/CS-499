function myFunction(){
	alert("Here is your discount code of 20% on all formal items! FORM20");
	}